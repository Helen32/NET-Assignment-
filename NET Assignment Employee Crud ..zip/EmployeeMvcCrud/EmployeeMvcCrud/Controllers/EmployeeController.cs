﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmployeeMvcCrud.Models;

namespace EmployeeMvcCrud.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            using (DbModels db = new DbModels())
            {
                return View(db.Employees.ToList());
            }
        }

        // GET: Employee/Details/5
        public ActionResult Details(int id)
        {
            using (DbModels db = new DbModels())
            {
                return View(db.Employees.Where(x => x.EmployeeId == id).FirstOrDefault());
            }
        }

        // GET: Employee/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        public ActionResult Create(Employee employee)
        {
            try
            {
                using (DbModels db = new DbModels())
                {
                    db.Employees.Add(employee);
                    db.SaveChanges();
                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int id)
        {
            using (DbModels db = new DbModels())
            {
                return View(db.Employees.Where(x => x.EmployeeId == id).FirstOrDefault());
            }
        }

        // POST: Employee/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Employee employee)
        {
            try
            {
                using (DbModels db = new DbModels())
                {

                    db.Entry(employee).State = EntityState.Modified;
                    db.SaveChanges();
                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int id)
        {
            using (DbModels db = new DbModels())
            {
                return View(db.Employees.Where(x => x.EmployeeId == id).FirstOrDefault());
            }
        }

        // POST: Employee/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Employee employee)
        {
            try
            {
                using (DbModels db = new DbModels())
                {
                    employee = db.Employees.Where(x => x.EmployeeId == id).FirstOrDefault();
                    db.Employees.Remove(employee);
                    db.SaveChanges();

                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
